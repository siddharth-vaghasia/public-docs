define([], function() {
  return {
    "Title": "ReferenceInjectorApplicationCustomizer"
  }
});