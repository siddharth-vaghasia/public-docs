declare interface IContentcontrolsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ContentcontrolsWebPartStrings' {
  const strings: IContentcontrolsWebPartStrings;
  export = strings;
}
