/* tslint:disable */
require("./Contentcontrols.module.css");
const styles = {
  contentcontrols: 'contentcontrols_8634c3b3',
  container: 'container_8634c3b3',
  row: 'row_8634c3b3',
  column: 'column_8634c3b3',
  'ms-Grid': 'ms-Grid_8634c3b3',
  title: 'title_8634c3b3',
  subTitle: 'subTitle_8634c3b3',
  description: 'description_8634c3b3',
  button: 'button_8634c3b3',
  label: 'label_8634c3b3'
};

export default styles;
/* tslint:enable */