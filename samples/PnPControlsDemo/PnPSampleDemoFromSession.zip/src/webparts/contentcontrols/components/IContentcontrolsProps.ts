
import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IContentcontrolsProps {
  description: string;
  context:WebPartContext;
}
