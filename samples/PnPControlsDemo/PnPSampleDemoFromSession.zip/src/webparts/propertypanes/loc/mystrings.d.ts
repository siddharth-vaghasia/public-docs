declare interface IPropertypanesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PropertypanesWebPartStrings' {
  const strings: IPropertypanesWebPartStrings;
  export = strings;
}
