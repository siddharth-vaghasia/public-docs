export interface IPropertypanesProps {
  description: string;
  multiSelect: string[];
  color:string;
}
