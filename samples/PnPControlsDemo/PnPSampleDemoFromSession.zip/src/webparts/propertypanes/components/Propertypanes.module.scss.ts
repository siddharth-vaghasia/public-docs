/* tslint:disable */
require("./Propertypanes.module.css");
const styles = {
  propertypanes: 'propertypanes_b207f03b',
  container: 'container_b207f03b',
  row: 'row_b207f03b',
  column: 'column_b207f03b',
  'ms-Grid': 'ms-Grid_b207f03b',
  title: 'title_b207f03b',
  subTitle: 'subTitle_b207f03b',
  description: 'description_b207f03b',
  button: 'button_b207f03b',
  label: 'label_b207f03b'
};

export default styles;
/* tslint:enable */