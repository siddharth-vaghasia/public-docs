/* tslint:disable */
require("./Listviewdemo.module.css");
const styles = {
  listviewdemo: 'listviewdemo_6fdd712d',
  container: 'container_6fdd712d',
  row: 'row_6fdd712d',
  column: 'column_6fdd712d',
  'ms-Grid': 'ms-Grid_6fdd712d',
  title: 'title_6fdd712d',
  subTitle: 'subTitle_6fdd712d',
  description: 'description_6fdd712d',
  button: 'button_6fdd712d',
  label: 'label_6fdd712d'
};

export default styles;
/* tslint:enable */