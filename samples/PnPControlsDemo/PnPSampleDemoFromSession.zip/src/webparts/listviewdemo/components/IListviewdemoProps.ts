export interface IListviewdemoProps {
  description: string;
  lists: string | string[]; // Stores the list ID(s)
}
