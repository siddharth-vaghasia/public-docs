declare interface IListviewdemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ListviewdemoWebPartStrings' {
  const strings: IListviewdemoWebPartStrings;
  export = strings;
}
