import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from './components/Header'
import OutlookConnectorDemo from './components/OutlookConnectorDemo'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Header appName="Office Users Demo" />
      
      <div className="full-width-section">
        <OutlookConnectorDemo 
          title="My Outlook Data"
          showEmails={true}
          showEvents={true}
          maxEmails={10}
          lookAheadTimeInMinutes={14400}
        />
      </div>
    </>
  )
}

export default App
