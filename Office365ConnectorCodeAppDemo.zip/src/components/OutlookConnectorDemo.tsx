import React, { useEffect, useState } from 'react';
import './OutlookConnectorDemo.css';
import { Office365OutlookService } from '../generated/services/Office365OutlookService';
import type { ClientReceiveMessageStringEnums } from '../generated/models/Office365OutlookModel';
import type { EntityListResponse_GraphCalendarEventClientReceive } from '../generated/models/Office365OutlookModel';

interface OutlookConnectorDemoProps {
  title?: string;
  showEmails?: boolean;
  showEvents?: boolean;
  maxEmails?: number;
  lookAheadTimeInMinutes?: number;
}

const OutlookConnectorDemo: React.FC<OutlookConnectorDemoProps> = ({
  title = 'Outlook Connector',
  showEmails = true,
  showEvents = true,
  maxEmails = 5,
  lookAheadTimeInMinutes = 60,
}) => {
  const [emails, setEmails] = useState<ClientReceiveMessageStringEnums[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [loadingEmails, setLoadingEmails] = useState(false);
  const [loadingEvents, setLoadingEvents] = useState(false);
  const [initialLoadComplete, setInitialLoadComplete] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [eventError, setEventError] = useState<string | null>(null);

  // Fetch emails
  const fetchEmails = async (): Promise<void> => {
    try {
      setLoadingEmails(true);
      setEmailError(null);

      const result = await Office365OutlookService.GetEmails(
        undefined,
        false,
        false,
        undefined,
        maxEmails
      );

      if (result && (result as any).data) {
        const emailList = Array.isArray((result as any).data) 
          ? (result as any).data 
          : [(result as any).data];
        setEmails(emailList);
      }
    } catch (err) {
      console.error('Error fetching emails:', err);
      setEmailError(err instanceof Error ? err.message : 'Failed to fetch emails');
    } finally {
      setLoadingEmails(false);
    }
  };

  // Fetch upcoming events
  const fetchUpcomingEvents = async (): Promise<void> => {
    try {
      setLoadingEvents(true);
      setEventError(null);

      const startDateTimeUtc = new Date().toISOString();
      const endDateTimeUtc = new Date(
        Date.now() + lookAheadTimeInMinutes * 60 * 1000
      ).toISOString();

      const result = await Office365OutlookService.GetEventsCalendarViewV3(
        'Calendar',
        startDateTimeUtc,
        endDateTimeUtc
      );

      if (result && (result as any).data) {
        const eventData = (result as any)
          .data as EntityListResponse_GraphCalendarEventClientReceive;
        setEvents(eventData.value || []);
      }
    } catch (err) {
      console.error('Error fetching events:', err);
      setEventError(err instanceof Error ? err.message : 'Failed to fetch events');
    } finally {
      setLoadingEvents(false);
    }
  };

  // Load data on component mount
  useEffect(() => {
    let isMounted = true;

    const loadInitialData = async () => {
      const tasks: Array<Promise<void>> = [];
      if (showEmails) {
        tasks.push(fetchEmails());
      }
      if (showEvents) {
        tasks.push(fetchUpcomingEvents());
      }

      try {
        await Promise.all(tasks);
      } finally {
        if (isMounted) {
          setInitialLoadComplete(true);
        }
      }
    };

    setInitialLoadComplete(false);
    loadInitialData();

    return () => {
      isMounted = false;
    };
  }, [showEmails, showEvents, maxEmails, lookAheadTimeInMinutes]);

  const renderEmails = () => {
    if (loadingEmails) {
      return <div className="loading">Loading emails...</div>;
    }

    if (emailError) {
      return <div className="error">Error: {emailError}</div>;
    }

    if (emails.length === 0) {
      return <div className="empty-state">No emails found</div>;
    }

    return (
      <div className="email-list">
        {emails.map((email, index) => (
          <div key={index} className="email-item">
            <div className="email-header">
              <h4 className="email-subject">{email.Subject || '(No Subject)'}</h4>
              <span className="email-date">
                {email.DateTimeReceived 
                  ? new Date(email.DateTimeReceived as string).toLocaleDateString()
                  : 'Unknown date'}
              </span>
            </div>
            <div className="email-from">
              <strong>From:</strong> {
                typeof email.From === 'string'
                  ? email.From
                  : 'Unknown sender'
              }
            </div>
            {email.BodyPreview && (
              <div className="email-preview">{email.BodyPreview}</div>
            )}
          </div>
        ))}
      </div>
    );
  };

  const renderEvents = () => {
    if (loadingEvents) {
      return <div className="loading">Loading events...</div>;
    }

    if (eventError) {
      return <div className="error">Error: {eventError}</div>;
    }

    if (events.length === 0) {
      return <div className="empty-state">No upcoming events</div>;
    }

    return (
      <div className="event-list">
        {events.map((event, index) => (
          <div key={index} className="event-item">
            <div className="event-header">
              <h4 className="event-subject">{event.subject || '(No Title)'}</h4>
              <span className="event-time">
                {event.start
                  ? new Date(event.start as string).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'TBD'}
              </span>
            </div>
            <div className="event-date">
              {event.start
                ? new Date(event.start as string).toLocaleDateString()
                : 'Unknown date'}
            </div>
            {event.organizer && (
              <div className="event-organizer">
                <strong>Organizer:</strong> {String(event.organizer)}
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  if (!initialLoadComplete) {
    return (
      <div className="outlook-connector-demo">
        <div className="loading">Loading Outlook data...</div>
      </div>
    );
  }

  return (
    <div className="outlook-connector-demo">
      <div className="connector-header">
        <h3>{title}</h3>
        <div className="connector-actions">
          {showEmails && (
            <button 
              className="refresh-btn" 
              onClick={fetchEmails}
              disabled={loadingEmails}
            >
              {loadingEmails ? 'Loading...' : 'Refresh Emails'}
            </button>
          )}
          {showEvents && (
            <button 
              className="refresh-btn" 
              onClick={fetchUpcomingEvents}
              disabled={loadingEvents}
            >
              {loadingEvents ? 'Loading...' : 'Refresh Events'}
            </button>
          )}
        </div>
      </div>

      {showEmails && showEvents ? (
        <div className="tabs-container">
          <div className="tab-section">
            <div className="tab-header">
              <h4>Emails ({emails.length})</h4>
              <button 
                className="refresh-btn-small" 
                onClick={fetchEmails}
                disabled={loadingEmails}
              >
                ⟳
              </button>
            </div>
            <div className="tab-content">
              {renderEmails()}
            </div>
          </div>
          <div className="tab-section">
            <div className="tab-header">
              <h4>Events ({events.length})</h4>
              <button 
                className="refresh-btn-small" 
                onClick={fetchUpcomingEvents}
                disabled={loadingEvents}
              >
                ⟳
              </button>
            </div>
            <div className="tab-content">
              {renderEvents()}
            </div>
          </div>
        </div>
      ) : showEmails ? (
        <div className="content">{renderEmails()}</div>
      ) : (
        <div className="content">{renderEvents()}</div>
      )}
    </div>
  );
};

export default OutlookConnectorDemo;
