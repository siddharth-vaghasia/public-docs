import React, { useEffect, useState } from 'react';
import './Header.css';
import reactLogo from '../assets/react.svg';
import { Office365UsersService } from '../generated/services/Office365UsersService';
import type { GraphUser_V1 } from '../generated/models/Office365UsersModel';

interface HeaderProps {
  appName?: string;
}

const Header: React.FC<HeaderProps> = ({
  appName = 'Office Users'
}) => {
  const [userProfile, setUserProfile] = useState<GraphUser_V1 | null>(null);
  const [profilePhoto, setProfilePhoto] = useState<string>('https://via.placeholder.com/45/667eea/ffffff?text=User');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch user profile
        const profileResult = await Office365UsersService.MyProfile_V2('displayName,mail,id');
        
        if (profileResult && (profileResult as any).data) {
          const profile = (profileResult as any).data as GraphUser_V1;
          setUserProfile(profile);

          // Fetch profile photo
          if (profile.id) {
            const photoResult = await Office365UsersService.UserPhoto_V2(profile.id);
            if (photoResult) {
              let photoData = (photoResult as any).data || photoResult;
              // Convert base64 to data URL
              if (photoData && typeof photoData === 'string') {
                const base64String = photoData.includes('data:image') ? photoData : `data:image/jpeg;base64,${photoData}`;
                setProfilePhoto(base64String);
              }
            }
          }
        }
      } catch (err) {
        console.error('Error fetching user data:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch user data');
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const displayName = userProfile?.displayName || 'User';
  const email = userProfile?.mail || '';

  return (
    <header className="header">
      {/* Left side - Logo */}
      <div className="header-left">
        <img src={reactLogo} alt="Logo" className="header-logo" />
      </div>

      {/* Center - App Name */}
      <div className="header-center">
        <h1 className="app-name">{appName}</h1>
      </div>

      {/* Right side - User Info */}
      <div className="header-right">
        <div className="user-info">
          <div className="user-details">
            <p className="welcome-text">Welcome</p>
            <p className="user-name">{loading ? 'Loading...' : displayName}</p>
            {email && <p className="user-email">{email}</p>}
            {error && <p className="user-error" title={error}>Error</p>}
          </div>
          <img 
            src={profilePhoto} 
            alt="Profile" 
            className="profile-image"
            title={displayName}
          />
        </div>
      </div>
    </header>
  );
};

export default Header;
